package com.example.boot_redis_kafka_mysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootRedisKafkaMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
